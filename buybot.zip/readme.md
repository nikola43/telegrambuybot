

https://github.com/mmabrouk/chatgpt-wrapper

python3 /Users/karonte/Library/Python/3.9/lib/python/site-packages/chatgpt_wrapper/chatgpt.py install