

from chatgpt_wrapper import ChatGPT
bot = ChatGPT()
response = bot.ask("Who is bitcoin creator?")
print(response)  # prints the response from chatGPT

